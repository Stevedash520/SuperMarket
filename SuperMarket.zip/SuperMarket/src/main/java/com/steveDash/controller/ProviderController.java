package com.steveDash.controller;

import com.alibaba.fastjson.JSONArray;
import com.steveDash.pojo.Provider;
import com.steveDash.pojo.Role;
import com.steveDash.pojo.User;
import com.steveDash.service.ProviderService;
import com.steveDash.tools.PageSupport;
import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
public class ProviderController {

    @Resource
    private ProviderService providerService;

    private Logger logger= Logger.getLogger(ProviderController.class);

    //获取供应商列表
    @RequestMapping(value="/providerlist")
    public String getProviderList(Model model,HttpSession session,
                              @RequestParam(value="queryname",required=false) String queryProviderName,
                              @RequestParam(value="pageIndex",required=false) String pageIndex) {
        logger.info("用户进入providerlist，供应商列表界面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provider就回到syserror
            return "redirect:/syserror";
        }

        List<Provider> providerList = null;
        //设置页面容量
        int pageSize = 5;
        //当前页码
        int currentPageNo = 1;

        if(queryProviderName == null){
            queryProviderName = "";
        }


        if(pageIndex != null){
            try{
                currentPageNo = Integer.valueOf(pageIndex);
            }catch(NumberFormatException e){
                return "redirect:/syserror";
            }
        }
        //总数量（表）
        int totalCount	= providerService.getProviderCount(queryProviderName);
        //总页数
        PageSupport pages=new PageSupport();
        pages.setCurrentPageNo(currentPageNo);
        pages.setPageSize(pageSize);
        pages.setTotalCount(totalCount);
        int totalPageCount = pages.getTotalPageCount();

        //控制首页和尾页

        //设置分页的每一页的显示从哪里开始
        int start = ((currentPageNo-1) * pageSize);

        if(currentPageNo < 1){
            currentPageNo = 1;
        }else if(currentPageNo > totalPageCount){
            currentPageNo = totalPageCount;
        }


        //若是想要展示出其他的信息，就需要在这部分，把对应的数据或者变量添加到model中，然后去前端设置接受参数即可。
        providerList = providerService.getProviderListByPage(queryProviderName,start,pageSize);
        model.addAttribute("providerList", providerList);
        model.addAttribute("queryProviderName", queryProviderName);
        model.addAttribute("totalPageCount", totalPageCount);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("currentPageNo", currentPageNo);
        return "provider";
    }

    //新增供应商页面
    @RequestMapping("/provideradd")
    public String showProviderAddPage(HttpSession session){
        logger.info("用户进入新增供应商界面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provideradd.jsp就回到login
            return "redirect:/syserror";
        }
        else
        return "provideradd";
    }

    //保存新的供应商
    @RequestMapping(value = "/provideraddsave",method = RequestMethod.POST)
    public String doProviderAdd(Provider provider,HttpSession session) throws Exception {
        logger.info("用户调用了保存新供应商的方法");
        //添加用户表的createBy值
        provider.setCreatedBy(((User)session.getAttribute("user")).getId());
        //添加用户表的createdDte值
        provider.setCreationDate((new Date()));
        if(providerService.addProvider(provider)==true){//如果添加成功就返回
            return "redirect:/providerlist";
        }
        return "provideradd";//添加不成功则返回注册界面
    }

    //验证供应商编码是否存在？
    @RequestMapping(value = "/proCodexist")
    @ResponseBody
    public Object proCodexist(@RequestParam String proCode){
        logger.info("用户调用了验证供应商编码是否存在的方法");
        String data="{\"proCode\":\"noexist\"}";  //初始化字符串
        if(proCode==null||proCode.length()==0){  //如果userCode是空值
            data="{\"proCode\":\"empty\"}";  //空值直接返回已存在
        }
        else{
            Provider provider = providerService.getProviderByProCode(proCode);
            if(provider!=null) {
                data = "{\"proCode\":\"exist\"}";
            }else{
                data="{\"proCode\":\"noexist\"}";
        }}
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }

    //添加一个供应商详细信息视图页面
    @RequestMapping(value="/providerview")
    public String showProviderViewPage(@RequestParam String proCode,Model model){
        logger.info("用户进入了供应商详细信息视图页面");
        Provider provider=providerService.getProviderByProCode(proCode);
        model.addAttribute(provider);
        return "providerview";
    }

    //修改某个供应商的信息
    @RequestMapping(value = "/providermodify")
    public String showProviderModifyPage(@RequestParam String proCode,Model model){
        logger.info("用户进入了供应商信息修改页面");
        Provider provider=providerService.getProviderByProCode(proCode);
        model.addAttribute(provider);
        return "providermodify";
    }

    //保存某个供应商的修改
    @RequestMapping(value = "/providermodifysave")
    public String modifyProvider(Provider provider,HttpSession session) throws Exception {
        provider.setModifyBy(((User)session.getAttribute("user")).getId());
        provider.setModifyDate(new Date());
        if(providerService.modifyProvider(provider)){
            return "redirect:/providerlist";
        }
        return "providermodify";
    }


    //删除某个供应商的信息
    @RequestMapping(value="/delprovider")
    @ResponseBody
    public Object delprovider(@RequestParam String proCode){
        logger.info("用户正在进行删除操作");
        String data="{\"delResult\":\"false\"}";  //初始化字符串
        Boolean result=providerService.deleteProviderByProCode(proCode);
        if(result==true){
            data="{\"delResult\":\"true\"}";//删除成功
        }else{
            data="{\"delResult\":\"false\"}";//删除未成功
        }
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }

}

