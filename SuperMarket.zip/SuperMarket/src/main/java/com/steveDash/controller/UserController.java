package com.steveDash.controller;


import com.alibaba.fastjson.JSONArray;
import com.steveDash.pojo.User;
import com.steveDash.service.ProviderService;
import com.steveDash.service.RoleService;
import com.steveDash.service.UserService;

import com.steveDash.tools.PageSupport;
import org.apache.log4j.Logger;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import com.steveDash.pojo.Role;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController {
    @Resource
    private UserService userService;
    @Resource
    private RoleService roleService;


    private Logger logger= Logger.getLogger(UserController.class);

    @RequestMapping("/default")
    public String hello(){
        System.out.println("访问到Controller");
        return "default";
    }



    @RequestMapping(value="/main")
    public String welcome(HttpSession session)  {
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到main.html就回到login
            return "redirect:/syserror";
        }
        else
            return "welcome";
    }

    @RequestMapping("/searchUser")
    public String search(){
        System.out.println("欢迎访问搜索页");
        return "searchUser";
    }

    @RequestMapping("/dosearchUser")
    public String searchUser(@RequestParam("username") String username, Model model){
        System.out.println("用户想要查询的用户名是："+username);
        model.addAttribute("username",username);//把值放到model中传到前端
        return "result";
    }

    @RequestMapping(value="/login")
    public String showLoginPage(){
        System.out.println("进入登录页面");
        return "login";
    }

    @RequestMapping(value="/dologin")
    public String doLogin(@RequestParam("userCode") String userCode, @RequestParam("userPassword") String userPassword, Model model, HttpSession session){
        //读取用户和密码
        System.out.println("帐号和密码是"+userCode+"-"+userPassword);
        User user=userService.getUserByUserCode(userCode);
        if(user!=null){
            if(userPassword.equals(user.getUserPassword())){
                session.setAttribute("user",user);//添加session值
                return "redirect:/main"; //密码正确就去welcome.jsp
            }else{
                //登录失败就回到login.jsp
                model.addAttribute("error", "用户名或密码不正确");
                return "login";
            }
        }else{
            //登录失败就返回login.jsp
            model.addAttribute("error", "用户名不正确");
            return "login";
        }
    }

    @RequestMapping(value = "/logout")
    public String logout(HttpSession session){
        session.removeAttribute("user");//清除掉Session 中的user值
        return "redirect:/login";//返回login.jsp
    }

    @RequestMapping("/syserror")//出错页面
    public String sysError(){
        return "syserror";
    }




    @RequestMapping("/useradd")
    public String showUserAddPage(HttpSession session){
        logger.info("用户登陆订单增加页面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provideradd.jsp就回到login
            return "redirect:/syserror";
        }
        logger.info("欢迎来到新增用户页面");
        return "useradd";
    }

    @RequestMapping(value = "/useraddsave",method = RequestMethod.POST)
    public String doUserAdd(User user,HttpSession session) throws Exception {
        //添加用户表的createBy值
        user.setCreatedBy(((User)session.getAttribute("user")).getId());
        //添加用户表的createdDte值
        user.setCreationDate((new Date()));
        if(userService.addUser(user)==true){//如果添加成功就返回
            return "redirect:/userlist";
        }
        return "useradd";//添加不成功则返回注册界面
    }


    //获取用户列表
    @RequestMapping(value="/userlist")
    public String getUserList(Model model,HttpSession session,
                              @RequestParam(value="queryname",required=false) String queryUserName,
                              @RequestParam(value="queryUserRole",required=false) String queryUserRole,
                              @RequestParam(value="pageIndex",required=false) String pageIndex) {
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到userlist就回到syserror
            return "redirect:/syserror";
        }
        int _queryUserRole = 0;
        List<User> userList = null;
        //设置页面容量
        int pageSize = 5;
        //当前页码
        int currentPageNo = 1;

        if(queryUserName == null){
            queryUserName = "";
        }
        if(queryUserRole != null && !queryUserRole.equals("")){
            _queryUserRole = Integer.parseInt(queryUserRole);
        }

        if(pageIndex != null){
            try{
                currentPageNo = Integer.valueOf(pageIndex);
            }catch(NumberFormatException e){
                return "redirect:/syserror";
            }
        }
        //总数量（表）
        int totalCount	= userService.getUserCount(queryUserName,_queryUserRole);
        //总页数
        PageSupport pages=new PageSupport();
        pages.setCurrentPageNo(currentPageNo);
        pages.setPageSize(pageSize);
        pages.setTotalCount(totalCount);
        int totalPageCount = pages.getTotalPageCount();

        //控制首页和尾页

        //设置分页的每一页的显示从哪里开始
        int start = ((currentPageNo-1) * pageSize);

        if(currentPageNo < 1){
            currentPageNo = 1;
        }else if(currentPageNo > totalPageCount){
            currentPageNo = totalPageCount;
        }


        //若是想要展示出其他的信息，就需要在这部分，把对应的数据或者变量添加到model中，然后去前端设置接受参数即可。
        userList = userService.getUserListByPage(queryUserName,_queryUserRole,start,pageSize);
        model.addAttribute("userList", userList);
        List<Role> roleList = null;
        roleList = roleService.getRoleList();
        model.addAttribute("roleList", roleList);
        model.addAttribute("queryUserName", queryUserName);
        model.addAttribute("queryUserRole", queryUserRole);
        model.addAttribute("totalPageCount", totalPageCount);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("currentPageNo", currentPageNo);
        return "userlist";
    }


    @RequestMapping(value="/usermodify")
    public String getUserById(@RequestParam String uid,Model model){
        User user = userService.getUserById(uid);
        model.addAttribute(user);
        return "usermodify";
    }

    @RequestMapping(value="/usermodifysave",method=RequestMethod.POST)
    public String modifyUserSave(User user,HttpSession session){
        user.setModifyBy(((User)session.getAttribute("user")).getId());
        user.setModifyDate(new Date());
        if(userService.modify(user)){
            return "redirect:/userlist";
        }
        return "usermodify";
    }


    //展示用户信息
    @RequestMapping(value="/userview")
    public String view(@RequestParam String uid,Model model){
        User user = userService.getUserById(uid);
        model.addAttribute(user);
        return "userview";
    }

    //删除用户数据
    @RequestMapping(value="/deluser")
    @ResponseBody
    public Object deluser(@RequestParam int uid){
        String data="{\"delResult\":\"false\"}";  //初始化字符串
        boolean result= userService.deleteUserById(uid);
        if(result==true)
            data="{\"delResult\":\"true\"}"; //删除成功
        else
            data="{\"delResult\":\"false\"}"; //删除失败
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }

    //判断是否存在userCode
    @RequestMapping(value="/ucexist")
    @ResponseBody
    public Object ucexist(@RequestParam String userCode){
        String data="{\"userCode\":\"noexist\"}";  //初始化字符串
        if(userCode==null||userCode.length()==0){  //如果userCode是空值
            data="{\"userCode\":\"exist\"}";  //空值直接返回已存在
        }
        else{
            User user = userService.selectUserCodeExist(userCode);
            if(user!=null)
                data="{\"userCode\":\"exist\"}";
            else
                data="{\"userCode\":\"noexist\"}";
        }
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }



    //注册密码修改页面
    @RequestMapping(value="/pwdmodify")
    public String showPwdModifyPage(){
        logger.info("进入密码修改页面");
        return "pwdmodify";
    }


    //修改密码的页面映射
    @RequestMapping(value="/pwdmodifysave")
    public String PwdModifyPage(@RequestParam String userCode,String newpassword,Model model,HttpSession session){
        logger.info("进行密码修改操作");
        User user = userService.getUserByUserCode(userCode);
        if(!user.getUserPassword().equals(newpassword)&&user.getUserPassword().length()!=newpassword.length()){
        user.setUserPassword(newpassword);
        }else{
            return "pwdmodify";

        }        if(userService.modify(user)){
            session.removeAttribute("user");//清除掉Session 中的user值
            return "redirect:/login";//返回login.jsp
        }else {
        return "pwdmodify";
        }
    }

    //判断用户输入的密码是否正确
    @RequestMapping(value ="/pwdjudge")
    @ResponseBody
    public Object pwdjudge(@RequestParam String userCode,String oldpassword,HttpSession session){
        String data="{\"result\":\"false\"}";  //初始化字符串
        if(oldpassword==null||oldpassword.length()==0){  //如果oldpassword是空值
            data="{\"result\":\"error\"}";  //空值直接返回密码错误
        }
        else{
            User user = userService.getUserByUserCode(userCode);
            if(user.getUserPassword().equals(oldpassword)) {
                data = "{\"result\":\"true\"}";
            }else if(session==null) {
                data="{\"result\":\"sessionerror\"}";
            }else
                data="{\"result\":\"false\"}";
        }
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }



}
