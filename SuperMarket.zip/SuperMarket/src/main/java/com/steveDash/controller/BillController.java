package com.steveDash.controller;

import com.alibaba.fastjson.JSONArray;
import com.steveDash.pojo.Bill;
import com.steveDash.pojo.Provider;
import com.steveDash.pojo.Role;
import com.steveDash.pojo.User;
import com.steveDash.service.BillService;
import com.steveDash.service.ProviderService;
import com.steveDash.tools.PageSupport;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
public class BillController {
    @Resource
    private BillService billService;
    @Resource
    private ProviderService providerService;

    private Logger logger=Logger.getLogger(BillController.class);

    @RequestMapping(value = "/billlist")
    public String showBillPage(Model model, HttpSession session,
                @RequestParam(value="queryProductName",required=false) String queryProductName,
                @RequestParam(value="queryProviderName",required=false) String queryProviderName,
                @RequestParam(value="pageIndex",required=false) String pageIndex) {
        logger.info("用户进入billlist，订单列表界面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provider就回到syserror
            return "redirect:/syserror";
        }

        List<Bill> billList = null;
        //设置页面容量
        int pageSize = 5;
        //当前页码
        int currentPageNo = 1;

        if(queryProductName == null){
            queryProductName = "";
        }

        if(queryProviderName == null){
            queryProviderName = "";
        }


        if(pageIndex != null){
            try{
                currentPageNo = Integer.valueOf(pageIndex);
            }catch(NumberFormatException e){
                return "redirect:/syserror";
            }
        }
        //总数量（表）
        int totalCount	= billService.getBillCount(queryProductName,queryProviderName);
        //总页数
        PageSupport pages=new PageSupport();
        pages.setCurrentPageNo(currentPageNo);
        pages.setPageSize(pageSize);
        pages.setTotalCount(totalCount);
        int totalPageCount = pages.getTotalPageCount();

        //控制首页和尾页

        //设置分页的每一页的显示从哪里开始
        int start = ((currentPageNo-1) * pageSize);

        if(currentPageNo < 1){
            currentPageNo = 1;
        }else if(currentPageNo > totalPageCount){
            currentPageNo = totalPageCount;
        }


        //若是想要展示出其他的信息，就需要在这部分，把对应的数据或者变量添加到model中，然后去前端设置接受参数即可。
        billList = billService.getBillListByCondition(queryProductName,queryProviderName,start,pageSize);
        model.addAttribute("billList", billList);
        model.addAttribute("queryProductName", queryProductName);
        model.addAttribute("queryProviderName", queryProviderName);
        model.addAttribute("totalPageCount", totalPageCount);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("currentPageNo", currentPageNo);
        return "billlist";
    }

    @RequestMapping(value = "/billAdd")
    public String showAddBillPage(Model model,HttpSession session){
        logger.info("用户登陆订单增加页面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provideradd.jsp就回到login
            return "redirect:/syserror";
        }
       List<Provider> providerList=providerService.selectFindAllProvider();
       model.addAttribute("providerList",providerList);
        return "billadd";
    }

    @RequestMapping(value = "/billAddSave",method = RequestMethod.POST)
    public  String doBillAdd(Bill bill,HttpSession session)throws  Exception{
        logger.info("用户进行新增订单操作");
        //添加订单表的createBy值
        bill.setCreatedBy(((User)session.getAttribute("user")).getId());
        //添加订单表的createdDte值
        bill.setCreationDate(new Date());
        if(billService.addBill(bill)){
        return "redirect:billlist";
        }
        return "billadd";
    }

    @RequestMapping(value = "/modifyBill")
    public String showModifyBillPage(@RequestParam String billCode,Model model,HttpSession session){
        logger.info("用户登录订单修改页面");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provideradd.jsp就回到login
            return "redirect:/syserror";
        }
        Bill bill =null;
        if(billCode!=null) {
                   bill= billService.getBillByBillCode(billCode);
            model.addAttribute(bill);
            List<Provider> providerList=providerService.selectFindAllProvider();
            model.addAttribute(providerList);
            return "billmodify";
        }else {
            return "redirect:/billlist";
        }

    }

    @RequestMapping(value = "/getProviderList")
    @ResponseBody
    public Object getProviderList(HttpSession session){
        logger.info("用户获取所有供应商信息");
        if(session.getAttribute("user") == null){ //如果用户没有登录就直接来到provideradd.jsp就回到login
            return "redirect:/syserror";
        }
        List<Provider> providerList=providerService.selectFindAllProvider();
        return JSONArray.toJSONString(providerList);
    }

    @RequestMapping(value = "/billmodifysave" ,method=RequestMethod.POST)
    public String modifyBillSave(Bill bill,HttpSession session) throws Exception {
        bill.setModifyBy(((User)session.getAttribute("user")).getId());
        bill.setModifyDate(new Date());
        if(billService.updateBillByBillCode(bill)){
         return "redirect:billlist";
        }else {
            return "modifyBill";
        }

    }

    @RequestMapping(value = "/billview")
    public String showBillView(@RequestParam String billCode,Model model,HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:syserror";
        }
        Bill bill=billService.getBillByBillCode(billCode);
        String proName=providerService.getProviderById(bill.getProviderId().toString()).getProName();
        model.addAttribute(bill);
        model.addAttribute(proName);
        return "billview";
    }

    @RequestMapping(value = "/deletebill")
    @ResponseBody
    public Object delbill(@RequestParam String billCode) throws Exception {
        String data="{\"delResult\":\"false\"}";  //初始化字符串
        boolean result= billService.deleteBillByBillCode(billCode);
        if(result==true)
            data="{\"delResult\":\"true\"}"; //删除成功
        else
            data="{\"delResult\":\"false\"}"; //删除失败
        return JSONArray.toJSONString(data);//将data转为json对象,并将结果发回给当前页面
    }


}
