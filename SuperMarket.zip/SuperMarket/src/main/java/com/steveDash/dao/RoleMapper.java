package com.steveDash.dao;

import com.steveDash.pojo.Role;

import java.util.List;

public interface RoleMapper {
    public List<Role> getRoleList();
}
