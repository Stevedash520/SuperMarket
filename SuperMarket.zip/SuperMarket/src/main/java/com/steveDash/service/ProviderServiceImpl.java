package com.steveDash.service;

import com.steveDash.dao.ProviderMapper;
import com.steveDash.pojo.Provider;

import com.steveDash.pojo.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;
@Service("providerService")
public class ProviderServiceImpl implements ProviderService {
    @Resource
    private ProviderMapper providerMapper;

    public ProviderMapper getProviderMapper() {
        return providerMapper;
    }

    public void setProviderMapper(ProviderMapper providerMapper) {
        this.providerMapper = providerMapper;
    }


    @Override
    public int getProviderCount(String queryProviderName) {
        int count=0;
        try{
            count=providerMapper.getProviderCount(queryProviderName);
        }catch (Exception e){
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public List<Provider> getProviderListByPage(String queryProviderName, int currentPageNo, int pageSize) {
        List<Provider> providerList=null;
        try{
            providerList=providerMapper.getProviderListByPage(queryProviderName,currentPageNo,pageSize);
        }catch (Exception e){
            e.printStackTrace();
        }

        return providerList;
    }

    @Override
    public Boolean addProvider(Provider provider) throws Exception {
        try{
            int result=providerMapper.addProvider(provider);
            if(result>0){
                return true;
            }else {
                return false;
            }
        }catch (IOException e){
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public Provider getProviderByProCode(String proCode) {
        Provider provider=null;
        try{
             provider=providerMapper.getProviderByProCode(proCode);
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
        return provider;
    }

    @Override
    public Provider getProviderById(String id) {
        Provider provider=null;
        try{
            provider= providerMapper.getProviderById(id);
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
        return provider;
    }

    @Override
    public Boolean modifyProvider(Provider provider) throws Exception {
        boolean result = false;
            try {
                int count = providerMapper.modifyProvider(provider);
                if (count > 0) { //������ӳɹ��ͷ���true
                    return true;
                } else{
                    return false;//�������ʧ�ܾͷ���false
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }



    @Override
    public Boolean deleteProviderByProCode(String proCode) {
        int result=providerMapper.deleteProviderByProCode(proCode);
        try{
            if(result>0){
                return true;
            }else return false;
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }

    }

    @Override
    public List<Provider> selectFindAllProvider() {
        try {
            return providerMapper.selectFindAllProvider();
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }

    }
}

