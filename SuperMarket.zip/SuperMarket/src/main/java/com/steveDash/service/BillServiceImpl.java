package com.steveDash.service;

import com.steveDash.dao.BillMapper;
import com.steveDash.pojo.Bill;
import com.steveDash.pojo.Provider;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("billService")
public class BillServiceImpl implements BillService {
    @Resource
    private BillMapper billMapper;

    public BillMapper getBillMapper() {
        return billMapper;
    }

    public void setBillMapper(BillMapper billMapper) {
        this.billMapper = billMapper;
    }

    @Override
    public List<Bill> getBillList() {
        return billMapper.getBillList();
    }

    @Override
    public List<Bill> getBillListByCondition(String productName, String ProviderName, Integer currentPageNo, Integer pageSize) {

        List<Bill> billList=null;
        try{
            billList=billMapper.getBillListByCondition(productName,ProviderName,currentPageNo,pageSize);
        }catch (Exception e){
            e.printStackTrace();
        }

        return billList;
    }

    @Override
    public int getBillCount(String productName, String proName) {
        int count=0;
        try{
            count=billMapper.getBillCount(productName,proName);
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
        return count;
    }

    @Override
    public Boolean addBill(Bill bill) throws Exception {
        int result=0;
        try{
            result=billMapper.addBill(bill);
            if(result>0){
                return true;
            }else {
                return false;
            }
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public Boolean updateBillByBillCode(Bill bill) throws Exception {
        int result=0;
        try{
            result=billMapper.updateBillByBillCode(bill);
            if(result>0){
                return  true;
            }else{
                return  false;
            }
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public Bill getBillByBillCode(String billCode) {
        try {
            Bill bill=billMapper.getBillByBillCode(billCode);
            return bill;
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }

    }

    @Override
    public Boolean deleteBillByBillCode(String billCode) throws Exception {
        try{
           int result=billMapper.deleteBillByBillCode(billCode);
           if(result>0){
               return  true;
           }else {
               return  false;
           }
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
    }
}
