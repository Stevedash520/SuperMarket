package com.steveDash.service;

import com.steveDash.dao.UserMapper;
import com.steveDash.pojo.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("userServiceImpl")
public class UserServiceImpl implements UserService {
    @Resource
    private UserMapper userMapper;

    public UserMapper getUserMapper() {
        return userMapper;
    }

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public User getUserByUserCode(String userCode) {
        try{
        return userMapper.getUserByUserCode(userCode);
    }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public int getUserCount(String queryUserName, int queryUserRole) {
        int count = 0;
        try {
            count=userMapper.getUserCount(queryUserName,queryUserRole);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public List<User> getUserListByPage(String queryUserName, int queryUserRole, int currentPageNo, int pageSize) {
        List<User> userList = null;

        try {
            userList=userMapper.getUserListByPage(queryUserName,queryUserRole,currentPageNo,pageSize);
        }
        catch (Exception e) {

            e.printStackTrace();
        }
        return userList;
    }


    @Override
    public Boolean addUser(User user) throws Exception {
        try{
          int count=userMapper.addUser(user);
          if (count>0){
              return true;
          }else {
              return false;
          }
        }catch (RuntimeException e){
            e.printStackTrace();
            throw e;
        }
    }


    @Override
    public User getUserById(String id) {
        User user=null;
        try{
            user=userMapper.getUserById(id);
        }
        catch (Exception e) {
            e.printStackTrace();
            user = null;
        }
        return user;
    }

    @Override
    public boolean modify(User user) {
        boolean result=false;
        try {
            int count=userMapper.modify(user);
            if(count>0)  //������ӳɹ��ͷ���true
                return true;
            else
                return false;//�������ʧ�ܾͷ���false
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    @Override
    public boolean deleteUserById(int id) {
        boolean result = false;
        try {
            if(userMapper.deleteUserById(id) > 0)
                result = true; //ɾ���ɹ�
            else
                result=false;  //ɾ��ʧ��
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public User selectUserCodeExist(String userCode) {
        User user = null;
        try {
            user = userMapper.getUserByUserCode(userCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

}
