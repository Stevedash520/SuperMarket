var proCode = null;
var proName = null;
var proContact = null;
var proPhone = null;
var proAddress=null;
var providerFax=null;
var proDesc=null;
var addBtn = null;
var backBtn = null;


$(function(){
	proCode = $("#proCode");
	proName = $("#proName");
	proContact = $("#proContact");
	proPhone = $("#proPhone");
	proAddress=$("#proAddress");
	providerFax=$("#providerFax");
	proDesc=$("#proDesc");
	addBtn = $("#add");
	backBtn = $("#back");
	//初始化的时候，要把所有的提示信息变为：* 以提示必填项，更灵活，不要写在页面上
	proCode.next().html("*");
	proName.next().html("*");
	proContact.next().html("*");
	proPhone.next().html("*");
	proAddress.next().html("*");
	providerFax.next().html("*");
	proDesc.next().html("*");






	/*
	 * 验证
	 * 失焦\获焦
	 * jquery的方法传递
	 */
	proCode.bind("blur",function(){
		$.ajax({
			type:"GET",//请求类型
			url:path+"/proCodexist",//请求的url
			data:{method:"proCodexist",proCode:proCode.val()},//请求参数
			dataType:"json",//ajax接口（请求url）返回的数据类型
			success:function(data){//data：返回数据（json对象）
				var data=$.parseJSON(data);//将字符串data解析为标准json对象
				if(data.proCode == "empty"){
					validateTip(proCode.next(),{"color":"red"},imgNo+" 编码不能为空，请重新输入",false);
				}
				else if(data.proCode == "exist"){//供应商账号已存在，错误提示
					validateTip(proCode.next(),{"color":"red"},imgNo+ " 该用户账号已存在",false);
				}else{//账号可用，正确提示
					validateTip(proCode.next(),{"color":"green"},imgYes+" 该账号可以使用",true);
				}
			}
		});
	}).on("focus",function(){
			if(proCode.val() != null && proCode.val() != ""){
				validateTip(proCode.next(),{"color":"green"},imgYes,true);
			}else{
				validateTip(proCode.next(),{"color":"red"},imgNo+" 编码不能为空，请重新输入",false);
			}
		//显示友情提示
		validateTip(proCode.next(),{"color":"#666666"},"* 请输入供应商编码",false);
	}).focus();
	
	proName.on("focus",function(){
		validateTip(proName.next(),{"color":"#666666"},"* 请输入供应商名称",false);
	}).on("blur",function(){
		if(proName.val() != null && proName.val() != ""){
			validateTip(proName.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(proName.next(),{"color":"red"},imgNo+" 供应商名称不能为空，请重新输入",false);
		}
		
	});
	
	proContact.on("focus",function(){
		validateTip(proContact.next(),{"color":"#666666"},"* 请输入联系人",false);
	}).on("blur",function(){
		if(proContact.val() != null && proContact.val() != ""){
			validateTip(proContact.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(proContact.next(),{"color":"red"},imgNo+" 联系人不能为空，请重新输入",false);
		}
		
	});
	
	proPhone.on("focus",function(){
		validateTip(proPhone.next(),{"color":"#666666"},"* 请输入手机号",false);
	}).on("blur",function(){
		var patrn=/^(13[0-9]|15[0-9]|18[0-9])\d{8}$/;
		if(proPhone.val().match(patrn)){
			validateTip(proPhone.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(proPhone.next(),{"color":"red"},imgNo + " 您输入的手机号格式不正确",false);
		}
	});

	proAddress.on("focus",function(){
		validateTip(proAddress.next(),{"color":"#666666"},"* 请输入供应商地址",false);
	}).on("blur",function(){
		if(proAddress.val() != null && proAddress.val() != ""){
			validateTip(proAddress.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(proAddress.next(),{"color":"red"},imgNo+" 供应商地址不能为空，请重新输入",false);
		}
	});

	providerFax.on("focus",function(){
		validateTip(providerFax.next(),{"color":"#666666"},"* 请输入供应商传真",false);
	}).on("blur",function(){
		if(providerFax.val() != null && providerFax.val() != ""){
			validateTip(providerFax.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(providerFax.next(),{"color":"red"},imgNo+" 供应商传真不能为空，请重新输入",false);
		}
	});

	proDesc.on("focus",function(){
		validateTip(proDesc.next(),{"color":"green"},"* 请输入供应商描述",true);
	}).on("blur",function(){
		if(proDesc.val() != null && proDesc.val() != ""){
			validateTip(proDesc.next(),{"color":"green"},imgYes,true);
		}else{
			validateTip(proDesc.next(),{"color":"green"},imgYes+" 请注意供应商详细信息为空，但是此项为非必须项",true);
		}
	});

	
	addBtn.bind("click",function(){
		event.preventDefault(); // 阻止默认的表单提交行为
		if(proCode.attr("validateStatus") != "true"){
			proCode.blur();
		}else if(proName.attr("validateStatus") != "true"){
			proName.blur();
		}else if(proContact.attr("validateStatus") != "true"){
			proContact.blur();
		}else if(proPhone.attr("validateStatus") != "true") {
			proPhone.blur();
		}else if(proAddress.attr("validateStatus") != "true"){
				proAddress.blur();
		}else if(providerFax.attr("validateStatus") != "true"){
			providerFax.blur();
		}else if(proDesc.attr("validateStatus") != "true"){
			proDesc.blur();
		}else{
			if(confirm("是否确认提交数据")){
				$("#providerForm").submit();
			}
		}
	});
	
	backBtn.on("click",function(){
		if(referer != undefined 
			&& null != referer 
			&& "" != referer
			&& "null" != referer
			&& referer.length > 4){
		 window.location.href = referer;
		}else{
			history.back(-1);
		}
	});
});