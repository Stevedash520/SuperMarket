var providerObj;

//供应商管理页面上点击删除按钮弹出删除框(providerlist.jsp)
function deleteProvider(obj){
	$.ajax({
		type:"GET",
		url:path+"/delprovider",
		data:{method:"delprovider",proCode:obj.attr("proCode")},
		dataType:"json",
		success:function(data){
			var data=$.parseJSON(data);//将字符串data解析为标准json对象
			if(data.delResult == "true"){//删除成功：移除删除行
				changeDLGContent("删除供应商【"+obj.attr("proCode")+"】成功");
				setTimeout(function () {
					cancleBtn();
					obj.parents("tr").remove();
				}, 2000); // 延迟2秒执行关闭弹窗和移除行的操作

			}else if(data.delResult == "false"){//删除失败

				changeDLGContent("对不起，删除供应商【"+obj.attr("proCode")+"】失败");
			}else if(data.delResult == "notexist"){

				changeDLGContent("对不起，供应商【"+obj.attr("proCode")+"】不存在");
			}else{

				changeDLGContent("对不起，该供应商【"+obj.attr("proCode")+"】下有【"+data.delResult+"】条订单，不能删除");
			}
		},
		error:function(data){
			//alert("对不起，删除失败");
			changeDLGContent("对不起，删除失败");
		}
	});
}

function openYesOrNoDLG(){
	$('.zhezhao').css('display', 'block');
	$('#removeProv').fadeIn();
}

function cancleBtn(){
	$('.zhezhao').css('display', 'none');
	$('#removeProv').fadeOut();
}
function changeDLGContent(contentStr){
	var p = $(".removeMain").find("p");
	p.html(contentStr);
}
$(function(){
	$(".viewProvider").on("click",function(){
		//将被绑定的元素（a）转换成jquery对象，可以使用jquery方法
		var obj = $(this);
		window.location.href=path+"/providerview?proCode="+ obj.attr("proCode");
	});
	
	$(".modifyProvider").on("click",function(){
		var obj = $(this);
		window.location.href=path+"/providermodify?proCode="+ obj.attr("proCode");
	});

	$('#no').click(function () {
		cancleBtn();
	});
	
	$('#yes').click(function () {
		deleteProvider(providerObj);
	});

	$(".deleteProvider").on("click",function(){
		providerObj = $(this);
		changeDLGContent("你确定要删除供应商【"+providerObj.attr("proCode")+"】吗？");
		openYesOrNoDLG();
	});
});